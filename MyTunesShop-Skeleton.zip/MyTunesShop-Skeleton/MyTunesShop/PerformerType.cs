﻿namespace MyTunesShop
{
    public enum PerformerType
    {
        Singer,
        Band
    }
}
